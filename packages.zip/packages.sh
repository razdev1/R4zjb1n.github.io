dpkg-deb -Zgzip -b Package
